#!/bin/bash
# Run after the jobs submitted by run_all.sh have finished
# (check with: squeue -u $USER)
# Usage: bash check_results.sh

set -u
RESULTS_FILE="job_ids.csv"

if [[ ! -f "$RESULTS_FILE" ]]; then
  echo "No $RESULTS_FILE found. Run run_all.sh first."
  exit 1
fi

echo "script,job_id,sacct_state,result_line"

tail -n +2 "$RESULTS_FILE" | while IFS=, read -r script job_id submit_status; do
  if [[ "$job_id" == "NA" || "$job_id" == "SKIPPED" ]]; then
    echo "$script,$job_id,$submit_status,\"(not run - see submit_status)\""
    continue
  fi

  STATE=$(sacct -j "$job_id" --format=State --noheader 2>/dev/null | head -1 | xargs)

  # Find this job's output file (pattern varies per script) and pull out
  # the line each test script prints starting with "RESULT:"
  OUTFILE=$(ls *_"${job_id}"*.out 2>/dev/null | head -1)
  if [[ -n "$OUTFILE" && -f "$OUTFILE" ]]; then
    RESULT_LINE=$(grep -m1 "RESULT:" "$OUTFILE" | tr -d '\n')
  else
    RESULT_LINE="(no output file found yet -- job may still be running)"
  fi

  echo "$script,$job_id,$STATE,\"$RESULT_LINE\""
done

echo ""
echo "Tip: pipe this through 'column -s, -t' for a readable table, e.g.:"
echo "  bash check_results.sh | column -s, -t"
