# tiCrypt Slurm Directive Support Test Suite

This folder contains small, self-contained `sbatch` scripts that each test **one**
Slurm directive (the equivalents of the SGE directives from the BU reference
table). Run them inside your tiCrypt enclave, then use the results to fill in
the "tiCrypt support" column.

## How to use

1. **Edit placeholders first.** A few scripts contain `<PROJECT>`, `<EMAIL>`,
   or GPU/CPU model names that are cluster-specific — replace these with real
   values for your enclave before submitting (grep for `<` to find them):
   ```bash
   grep -rl '<[A-Z_]*>' .
   ```

2. **Submit each test individually** (recommended the first time, so you can
   read each result before moving to the next):
   ```bash
   sbatch 01_general/test_time.sh
   ```
   Two outcomes matter:
   - **sbatch itself rejects the job** (prints an error like
     `sbatch: error: Invalid directive` or `unrecognized option`) → directive
     is **not supported / not recognized**.
   - **sbatch accepts it and the job runs** → check the `.out` file it
     produces. Each script prints a `RESULT: PASS` or `RESULT: FAIL` line
     based on whether the requested setting was actually honored at runtime
     (not just accepted at submission time — some schedulers silently accept
     and ignore directives).

3. **Or submit everything at once** and collect results automatically:
   ```bash
   bash run_all.sh          # submits every test, records job IDs
   bash check_results.sh    # waits for completion, prints a summary table
   ```

4. **Record the outcome** for each directive back into
   `sge-slurm-job-directives.md`, replacing "To check" with:
   - `Yes` — sbatch accepted it and the runtime check confirmed it took effect
   - `No` — sbatch rejected it, or it was silently ignored at runtime
   - `Partial` — accepted and partially honored (e.g., accepted but capped/clamped)

## Notes on directives that can't be fully verified by a script

- **`--mail-type` / `--mail-user`** — the script confirms Slurm *registered*
  the mail settings (via `scontrol show job`), but only you can confirm
  whether the email actually arrived (enclaves are often network-isolated
  and may block outbound mail entirely, which is a likely failure mode for
  tiCrypt specifically).
- **`-j y` (merged stdout/stderr)** — there's no Slurm flag to test; the
  script demonstrates the standard workaround (omit `--error` so both streams
  go to `--output`) and confirms that works within tiCrypt.
- **`--dependency`** — requires two jobs; `test_dependency.sh` submits both
  itself and confirms job2 waited for job1.
- **GPU / CPU-feature constraints** (`--gpus`, `--constraint=avx2`, etc.) —
  results depend on what hardware/features actually exist in your tiCrypt
  enclave's compute nodes. A "FAIL" here may mean "not supported" or simply
  "no matching hardware in this enclave" — check the sbatch error message to
  tell the difference (no matching nodes usually gives a distinct pending
  reason like `Resources` or `ReqNodeNotAvail`, or an immediate rejection).
