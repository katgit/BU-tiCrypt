#!/bin/bash
# Driver script (run directly, NOT with sbatch) that submits two jobs and
# tests whether job2 correctly waits for job1 (SGE: -hold_jid).

set -e

cat > /tmp/t_dep_job1.sh <<'EOF'
#!/bin/bash
#SBATCH --job-name=t_dep_job1
#SBATCH --time=00:02:00
#SBATCH --output=t_dep_job1_%j.out
#SBATCH --ntasks=1
echo "job1 starting: $(date)"
sleep 30
echo "job1 finished: $(date)"
EOF

cat > /tmp/t_dep_job2.sh <<'EOF'
#!/bin/bash
#SBATCH --job-name=t_dep_job2
#SBATCH --time=00:02:00
#SBATCH --output=t_dep_job2_%j.out
#SBATCH --ntasks=1
echo "job2 starting: $(date)"
echo "(if dependency worked, this timestamp should be AFTER job1 finished)"
EOF

JOB1_ID=$(sbatch --parsable /tmp/t_dep_job1.sh)
echo "Submitted job1: $JOB1_ID"

JOB2_ID=$(sbatch --parsable --dependency=afterok:${JOB1_ID} /tmp/t_dep_job2.sh)
echo "Submitted job2: $JOB2_ID (depends on afterok:${JOB1_ID})"

echo ""
echo "=== Testing --dependency=afterok (SGE: -hold_jid) ==="
echo "Immediately after submission, job2 should show state PENDING with"
echo "reason 'Dependency'. Check with:"
echo "  squeue -j ${JOB2_ID} -o '%.18i %.9P %.20j %.8T %.10M %R'"
echo ""
echo "After both complete, compare timestamps in t_dep_job1_${JOB1_ID}.out"
echo "and t_dep_job2_${JOB2_ID}.out:"
echo "RESULT: PASS if job2's start timestamp is after job1's finish timestamp"
echo "RESULT: FAIL if job2 ran concurrently with or before job1"
