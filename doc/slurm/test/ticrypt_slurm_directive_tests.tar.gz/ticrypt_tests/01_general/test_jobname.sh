#!/bin/bash
#SBATCH --job-name=ticrypt_test_jobname
#SBATCH --time=00:02:00
#SBATCH --output=t_jobname_%j.out
#SBATCH --ntasks=1

echo "=== Testing --job-name (SGE: -N) ==="
echo "SLURM_JOB_NAME=$SLURM_JOB_NAME"

if [[ "$SLURM_JOB_NAME" == "ticrypt_test_jobname" ]]; then
  echo "RESULT: PASS - job name was honored"
else
  echo "RESULT: FAIL - job name mismatch (got '$SLURM_JOB_NAME')"
fi
