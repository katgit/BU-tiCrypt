#!/bin/bash
#SBATCH --job-name=t_export_var
#SBATCH --export=MYVAR=ticrypt_test_value
#SBATCH --time=00:02:00
#SBATCH --output=t_export_var_%j.out
#SBATCH --ntasks=1

echo "=== Testing --export=env=value (SGE: -v env=value) ==="
echo "MYVAR=$MYVAR"

if [[ "$MYVAR" == "ticrypt_test_value" ]]; then
  echo "RESULT: PASS - single variable export was honored"
else
  echo "RESULT: FAIL - variable was not set as requested"
fi
