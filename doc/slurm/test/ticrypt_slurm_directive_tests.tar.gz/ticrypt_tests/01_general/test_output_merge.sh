#!/bin/bash
#SBATCH --job-name=t_merge
#SBATCH --output=t_merge_%j.out
#SBATCH --time=00:02:00
#SBATCH --ntasks=1
# Intentionally no --error line: this is the equivalent of SGE's "-j y"

echo "This is stdout"
echo "This is stderr" >&2

echo ""
echo "RESULT: open t_merge_<jobid>.out - if it contains BOTH lines above,"
echo "the omit-error merge workaround is supported (equivalent to -j y)."
