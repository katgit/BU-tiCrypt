#!/bin/bash
#SBATCH --job-name=t_outerr
#SBATCH --output=t_outerr_stdout_%j.log
#SBATCH --error=t_outerr_stderr_%j.log
#SBATCH --time=00:02:00
#SBATCH --ntasks=1

# This job writes to both stdout and stderr, then a separate step below
# (run manually) verifies that -j y's merge behavior can be replicated by
# simply NOT specifying --error.

echo "This line goes to stdout (custom --output file)"
echo "This line goes to stderr (custom --error file)" >&2

echo "RESULT: check that t_outerr_stdout_<jobid>.log contains the stdout line"
echo "RESULT: check that t_outerr_stderr_<jobid>.log contains the stderr line"
echo "If both files exist with correct content -> --output/--error PASS"
echo ""
echo "=== Note on SGE -j y (merge stdout+stderr) ==="
echo "Slurm has no direct '-j y' flag. The standard equivalent is to omit"
echo "--error entirely, so both streams land in the file given by --output."
echo "See test_output_merge.sh for that specific test."
