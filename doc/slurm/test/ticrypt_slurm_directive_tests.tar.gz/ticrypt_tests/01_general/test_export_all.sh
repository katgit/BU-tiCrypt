#!/bin/bash
#SBATCH --job-name=t_export_all
#SBATCH --export=ALL
#SBATCH --time=00:02:00
#SBATCH --output=t_export_all_%j.out
#SBATCH --ntasks=1

# Before submitting, run in your shell:  export MY_TEST_VAR="hello_ticrypt"
# then: sbatch test_export_all.sh

echo "=== Testing --export=ALL (SGE: -V) ==="
echo "MY_TEST_VAR=$MY_TEST_VAR"

if [[ "$MY_TEST_VAR" == "hello_ticrypt" ]]; then
  echo "RESULT: PASS - submission-time environment was exported to the job"
else
  echo "RESULT: FAIL - environment variable was not passed through"
  echo "(Did you 'export MY_TEST_VAR=hello_ticrypt' in your shell before sbatch?)"
fi
