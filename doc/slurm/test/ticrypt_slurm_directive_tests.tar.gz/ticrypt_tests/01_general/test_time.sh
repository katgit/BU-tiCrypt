#!/bin/bash
#SBATCH --job-name=t_time
#SBATCH --time=00:05:00
#SBATCH --output=t_time_%j.out
#SBATCH --ntasks=1

echo "=== Testing --time (SGE: -l h_rt) ==="
LIMIT=$(scontrol show job "$SLURM_JOB_ID" | grep -oP 'TimeLimit=\S+')
echo "Reported: $LIMIT"

if [[ "$LIMIT" == "TimeLimit=00:05:00" ]]; then
  echo "RESULT: PASS - requested 5 min time limit was honored"
else
  echo "RESULT: FAIL - time limit does not match request ($LIMIT)"
fi
