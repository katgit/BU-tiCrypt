#!/bin/bash
#SBATCH --job-name=t_account
#SBATCH --account=<PROJECT>
#SBATCH --time=00:02:00
#SBATCH --output=t_account_%j.out
#SBATCH --ntasks=1

echo "=== Testing --account (SGE: -P) ==="
echo "SLURM_JOB_ACCOUNT=$SLURM_JOB_ACCOUNT"
ACCT=$(scontrol show job "$SLURM_JOB_ID" | grep -oP 'Account=\S+')
echo "Reported: $ACCT"

if [[ -n "$SLURM_JOB_ACCOUNT" && "$SLURM_JOB_ACCOUNT" != "(null)" ]]; then
  echo "RESULT: PASS - account was set to $SLURM_JOB_ACCOUNT"
else
  echo "RESULT: FAIL - no account was associated with the job"
fi
