#!/bin/bash
#SBATCH --job-name=t_mail
#SBATCH --mail-type=BEGIN,END,FAIL
#SBATCH --mail-user=<EMAIL>
#SBATCH --time=00:02:00
#SBATCH --output=t_mail_%j.out
#SBATCH --ntasks=1

echo "=== Testing --mail-type / --mail-user (SGE: -m / -M) ==="
scontrol show job "$SLURM_JOB_ID" | grep -i mail
echo ""
echo "RESULT: scontrol output above shows what Slurm registered."
echo "RESULT: Separately confirm whether an email actually arrived at"
echo "<EMAIL> for job begin/end -- tiCrypt enclaves are often"
echo "network-isolated and may block outbound mail even if Slurm accepts"
echo "the directive, so 'accepted by Slurm' and 'mail delivered' are"
echo "two different PASS/FAIL checks."
