#!/bin/bash
#SBATCH --job-name=t_array
#SBATCH --array=1-5
#SBATCH --time=00:02:00
#SBATCH --output=t_array_%A_%a.out
#SBATCH --ntasks=1

echo "=== Testing --array (SGE: -t N) ==="
echo "SLURM_ARRAY_JOB_ID=$SLURM_ARRAY_JOB_ID"
echo "SLURM_ARRAY_TASK_ID=$SLURM_ARRAY_TASK_ID"
echo "SLURM_ARRAY_TASK_COUNT=$SLURM_ARRAY_TASK_COUNT"

if [[ -n "$SLURM_ARRAY_TASK_ID" ]]; then
  echo "RESULT: PASS (this task) - task ID $SLURM_ARRAY_TASK_ID of the array ran"
else
  echo "RESULT: FAIL - no array task ID set; array submission may not be supported"
fi
echo "After all 5 tasks complete, confirm 5 separate output files exist:"
echo "  ls t_array_<jobid>_*.out"
