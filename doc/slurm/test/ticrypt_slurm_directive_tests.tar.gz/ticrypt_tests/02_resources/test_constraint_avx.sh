#!/bin/bash
#SBATCH --job-name=t_avx
#SBATCH --constraint=avx2
#SBATCH --time=00:02:00
#SBATCH --output=t_avx_%j.out
#SBATCH --ntasks=1

# Edit --constraint above to avx / avx2 / avx512 to test each tier
# individually (SGE: -l avx / -l avx2 / -l avx512). This assumes your
# tiCrypt Slurm config actually defines "avx"/"avx2"/"avx512" as node
# features -- if it doesn't, sbatch will reject the job with "Invalid
# feature specification" regardless of whether the hardware supports it.

echo "=== Testing --constraint=avx2 (SGE: -l avx2) ==="
lscpu | grep -oE 'avx[0-9]*' | sort -u
echo ""
echo "RESULT: PASS if job ran AND lscpu flags above include avx2"
echo "RESULT: FAIL if sbatch rejected the constraint at submission time"
echo "        (means the feature isn't defined in tiCrypt's Slurm config,"
echo "         even if the underlying CPU supports it)"
