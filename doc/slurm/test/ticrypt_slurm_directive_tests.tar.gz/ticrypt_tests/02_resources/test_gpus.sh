#!/bin/bash
#SBATCH --job-name=t_gpu
#SBATCH --gpus=1
#SBATCH --time=00:02:00
#SBATCH --output=t_gpu_%j.out
#SBATCH --ntasks=1

echo "=== Testing --gpus (SGE: -l gpus) ==="
echo "CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES"
echo "SLURM_GPUS=$SLURM_GPUS"
which nvidia-smi >/dev/null 2>&1 && nvidia-smi -L

if [[ -n "$CUDA_VISIBLE_DEVICES" ]]; then
  echo "RESULT: PASS - a GPU was allocated to the job"
else
  echo "RESULT: FAIL or NO-GPU-NODE - check whether tiCrypt enclave has any"
  echo "GPU-backed nodes at all before concluding the directive is unsupported."
fi
