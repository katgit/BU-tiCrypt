#!/bin/bash
#SBATCH --job-name=t_gpu_type
#SBATCH --gpus=<GPU_MODEL>:1
#SBATCH --time=00:02:00
#SBATCH --output=t_gpu_type_%j.out
#SBATCH --ntasks=1

# Replace <GPU_MODEL> with a real GPU type name configured in your tiCrypt
# enclave's Slurm GRES (equivalent to SGE's gpu_type, e.g. a100, a40).

echo "=== Testing --gpus=MODEL:N (SGE: -l gpu_type) ==="
which nvidia-smi >/dev/null 2>&1 && nvidia-smi -L
echo "RESULT: PASS if the GPU listed above matches <GPU_MODEL>."
echo "RESULT: FAIL if sbatch rejects an unknown GPU type name, or a"
echo "different GPU model was allocated."
