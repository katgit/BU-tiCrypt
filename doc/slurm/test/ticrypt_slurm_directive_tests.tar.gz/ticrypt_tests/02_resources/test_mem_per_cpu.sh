#!/bin/bash
#SBATCH --job-name=t_mem
#SBATCH --mem-per-cpu=4G
#SBATCH --time=00:02:00
#SBATCH --output=t_mem_%j.out
#SBATCH --ntasks=1

echo "=== Testing --mem-per-cpu (SGE: -l mem_per_core) ==="
scontrol show job "$SLURM_JOB_ID" | grep -oP 'MinMemoryCPU=\S+'
echo "SLURM_MEM_PER_CPU=$SLURM_MEM_PER_CPU"

if [[ "$SLURM_MEM_PER_CPU" == "4096" || "$SLURM_MEM_PER_CPU" == "4G" ]]; then
  echo "RESULT: PASS - 4G per CPU was honored"
else
  echo "RESULT: CHECK - compare MinMemoryCPU above to the requested 4G (unit may be MB)"
fi
