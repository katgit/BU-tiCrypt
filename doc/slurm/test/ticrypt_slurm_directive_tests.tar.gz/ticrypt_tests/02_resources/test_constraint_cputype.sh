#!/bin/bash
#SBATCH --job-name=t_cputype
#SBATCH --constraint=<CPU_MODEL_FEATURE>
#SBATCH --time=00:02:00
#SBATCH --output=t_cputype_%j.out
#SBATCH --ntasks=1

# Replace <CPU_MODEL_FEATURE> with a real feature name on your tiCrypt nodes
# (equivalent to SGE's cpu_type, e.g. Gold-6132). Find valid names with:
# scontrol show node | grep -i features

echo "=== Testing --constraint for CPU model (SGE: -l cpu_type) ==="
lscpu | grep -i "model name"
echo "RESULT: same pass/fail logic as test_constraint_arch.sh"
