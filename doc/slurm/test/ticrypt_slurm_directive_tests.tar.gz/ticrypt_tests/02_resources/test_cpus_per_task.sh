#!/bin/bash
#SBATCH --job-name=t_cpus
#SBATCH --cpus-per-task=4
#SBATCH --time=00:02:00
#SBATCH --output=t_cpus_%j.out
#SBATCH --ntasks=1

echo "=== Testing --cpus-per-task (SGE: -pe omp N) ==="
echo "SLURM_CPUS_PER_TASK=$SLURM_CPUS_PER_TASK"
NPROC=$(nproc)
echo "nproc reports: $NPROC"

if [[ "$SLURM_CPUS_PER_TASK" == "4" ]]; then
  echo "RESULT: PASS - 4 CPUs per task were allocated"
else
  echo "RESULT: FAIL - requested 4, got $SLURM_CPUS_PER_TASK"
fi
