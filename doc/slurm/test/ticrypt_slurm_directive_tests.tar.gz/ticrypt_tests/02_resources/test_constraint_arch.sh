#!/bin/bash
#SBATCH --job-name=t_arch
#SBATCH --constraint=<ARCH_FEATURE>
#SBATCH --time=00:02:00
#SBATCH --output=t_arch_%j.out
#SBATCH --ntasks=1

# Replace <ARCH_FEATURE> with a real feature name defined on your tiCrypt
# nodes (equivalent to SGE's cpu_arch, e.g. broadwell/cascadelake). Find
# valid feature names with: scontrol show node | grep -i features

echo "=== Testing --constraint (SGE: -l cpu_arch) ==="
scontrol show job "$SLURM_JOB_ID" | grep -i features
lscpu | grep -i "model name"

echo "RESULT: if the job ran (didn't stay pending/rejected) and landed on a"
echo "node with the requested feature, --constraint is supported."
echo "If sbatch rejected the job at submission ('Invalid feature'), it is not."
