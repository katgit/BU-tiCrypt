#!/bin/bash
#SBATCH --job-name=t_mpi
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=4
#SBATCH --time=00:02:00
#SBATCH --output=t_mpi_%j.out

echo "=== Testing --nodes/--ntasks-per-node (SGE: -pe mpi_#_tasks_per_node) ==="
echo "SLURM_JOB_NUM_NODES=$SLURM_JOB_NUM_NODES"
echo "SLURM_NTASKS_PER_NODE=$SLURM_NTASKS_PER_NODE"
echo "SLURM_NTASKS=$SLURM_NTASKS"
echo "SLURM_JOB_NODELIST=$SLURM_JOB_NODELIST"

if [[ "$SLURM_JOB_NUM_NODES" == "2" && "$SLURM_NTASKS_PER_NODE" == "4" ]]; then
  echo "RESULT: PASS - 2 nodes x 4 tasks/node were allocated"
else
  echo "RESULT: FAIL - allocation does not match request"
  echo "(if the job never leaves PENDING, the enclave may not have 2+ nodes available)"
fi
