#!/bin/bash
# Submits every single-directive test (skips test_dependency.sh, which
# submits its own pair of jobs -- run that one separately).
# Usage: bash run_all.sh
# Requires: placeholders in scripts (e.g. <PROJECT>, <EMAIL>, <GPU_MODEL>)
# already filled in, or those specific tests will be skipped/fail.

set -u
RESULTS_FILE="job_ids.csv"
echo "script,job_id,submit_status" > "$RESULTS_FILE"

SCRIPTS=$(find 01_general 02_resources -maxdepth 1 -name 'test_*.sh' | grep -v test_dependency.sh | sort)

for s in $SCRIPTS; do
  if grep -q '<[A-Z_]*>' "$s"; then
    echo "SKIP: $s still has an unfilled placeholder (<...>). Edit it first."
    echo "$s,SKIPPED,unfilled_placeholder" >> "$RESULTS_FILE"
    continue
  fi
  OUT=$(sbatch --parsable "$s" 2>&1)
  if [[ $? -eq 0 ]]; then
    echo "SUBMITTED: $s -> job $OUT"
    echo "$s,$OUT,submitted" >> "$RESULTS_FILE"
  else
    echo "REJECTED at submission: $s -> $OUT"
    echo "$s,NA,\"$OUT\"" >> "$RESULTS_FILE"
  fi
done

echo ""
echo "Done. Recorded to $RESULTS_FILE."
echo "Run 'bash check_results.sh' once jobs finish (check with squeue -u \$USER)."
echo "Separately run: bash 01_general/test_dependency.sh"
